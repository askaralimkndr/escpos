<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Print_demo extends CI_Controller {
	public function index()
	{
		$this->load->library("EscPos.php");
		$connector = new FilePrintConnector("/dev/usb/lp0");
	    /* Print a "Hello world" receipt" */
	    $printer = new Printer($connector);
	    $printer -> text("Hello World!\n");
	    $printer -> cut();
	    /* Close printer */
	    $printer -> close();

	}

}

/* End of file Print.php */
/* Location: ./application/controllers/Print.php */